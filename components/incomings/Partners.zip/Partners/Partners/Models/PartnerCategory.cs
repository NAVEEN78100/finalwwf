﻿namespace Partners.Models
{
    public enum PartnerCategory
    {
        StarDines = 1,
        RestoBars = 2,
        HangoutSpot = 3,
        Homebakers = 4
    }
}
